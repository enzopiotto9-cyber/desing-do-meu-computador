﻿=== mini cursors.ani Cursor Set ===

By: ⎛⎝ Gabriel ⎠⎞ (http://www.rw-designer.com/user/98412) criatividadepqsimc@gmail.com

Download: http://www.rw-designer.com/cursor-set/mini-cursors-ani

Author's description:



==========

License: Released to Public Domain

You are free:

* To use this work for any legal purpose.